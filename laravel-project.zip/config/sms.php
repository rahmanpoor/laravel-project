<?php


namespace App\Http\Services\Message\SMS;



return [

'api_url' => env('MELIPAYAMAK_API_URL'),

'api_key' => env('MELIPAYAMAK_API_KEY'),

];





