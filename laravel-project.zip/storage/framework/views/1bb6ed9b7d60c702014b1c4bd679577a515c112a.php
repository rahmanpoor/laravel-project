<?php $__env->startSection('head-tag'); ?>
    <title>ویرایش کالا</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin-asset/jalalidatepicker/persian-datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item font-size-12"> <a href="#">خانه</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">بخش فروش</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">کالا </a></li>
            <li class="breadcrumb-item font-size-12 active" aria-current="page"> ویرایش کالا</li>
        </ol>
    </nav>


    <section class="row">
        <section class="col-12">
            <section class="main-body-container">
                <section class="main-body-container-header">
                    <h5>
                        ویرایش کالا
                    </h5>
                </section>

                <section class="d-flex justify-content-between align-items-center mt-4 mb-3 border-bottom pb-2">
                    <a href="<?php echo e(route('admin.market.product.index')); ?>" class="btn btn-info btn-sm">بازگشت</a>
                </section>

                <section>
                    <form action="<?php echo e(route('admin.market.product.update', $product->id)); ?>" method="post" id="form"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <section class="row">

                            <section class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="">نام کالا</label>
                                    <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>"
                                        class="form-control form-control-sm">
                                </div>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>

                            <section class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="">انتخاب دسته</label>
                                    <select name="category_id" id="" class="form-control form-control-sm">
                                        <option value="">دسته را انتخاب کنید</option>
                                        <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($productCategory->id); ?>"
                                                <?php if(old('category_id', $product->category_id) == $productCategory->id): ?> selected <?php endif; ?>>
                                                <?php echo e($productCategory->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>


                            <section class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="">انتخاب برند</label>
                                    <select name="brand_id" id="" class="form-control form-control-sm">
                                        <option value="">برند را انتخاب کنید</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"
                                                <?php if(old('brand_id', $product->brand_id) == $brand->id): ?> selected <?php endif; ?>>
                                                <?php echo e($brand->persian_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>


                            <section class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="">تصویر </label>
                                    <input type="file" name="image" class="form-control form-control-sm">
                                </div>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>

                            <section class="row">
                                <?php
                                    $number = 1;
                                ?>
                                <?php $__currentLoopData = $product->image['indexArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <section class="col-md-<?php echo e(6 / $number); ?>">
                                        <div class="form-check">
                                            <input type="radio" class="form-check-input" name="currentImage"
                                                value="<?php echo e($key); ?>" id="<?php echo e($number); ?>"
                                                <?php if($product->image['currentImage'] == $key): ?> checked <?php endif; ?>>
                                            <label for="<?php echo e($number); ?>" class="form-check-label mx-2">
                                                <img src="<?php echo e(asset($value)); ?>" class="w-100" alt="">
                                            </label>
                                        </div>
                                    </section>
                                    <?php
                                        $number++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </section>

                            


                            <section class="col-12">
                                <div class="form-group">
                                    <label for="price">قیمت کالا (تومان)</label>
                                    <input type="text" name="price" id="price"
                                        value="<?php echo e(priceFormat(old('price', $product->price))); ?>" class="form-control form-control-sm"
                                        oninput="formatPrice(this)">
                                </div>
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>

                            <section class="col-12">
                                <div class="form-group">
                                    <label for="">توضیحات</label>
                                    <textarea name="introduction" id="introduction" class="form-control form-control-sm" rows="6"><?php echo e(old('introduction', $product->introduction)); ?></textarea>
                                </div>
                                <?php $__errorArgs = ['introduction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>

                            <section class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="status">وضعیت</label>
                                    <select name="status" id="" class="form-control form-control-sm"
                                        id="status">
                                        <option value="0" <?php if(old('status', $product->status) == 0): ?> selected <?php endif; ?>>غیرفعال
                                        </option>
                                        <option value="1" <?php if(old('status', $product->status) == 1): ?> selected <?php endif; ?>>فعال
                                        </option>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>

                            

                            <section class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="tags">تگ ها</label>
                                    <input type="hidden" class="form-control form-control-sm" name="tags"
                                        id="tags" value="<?php echo e(old('tags', $product->tags)); ?>">
                                    <select class="select2 form-control form-control-sm" id="select_tags" multiple>

                                    </select>
                                </div>
                                <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert_required text-danger p-1">
                                        <strong>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </section>

                            


                            <section class="col-12 border-top border-bottom py-3 mb-3">

                                <?php $__currentLoopData = $product->metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <section class="row">

                                        <section class="col-6 col-md-3">
                                            <div class="form-group">
                                                <input type="text" name="meta_key[<?php echo e($meta->id); ?>]"
                                                    class="form-control form-control-sm" value="<?php echo e($meta->meta_key); ?>">
                                            </div>
                                            <?php $__errorArgs = ['meta_key.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="alert_required text-danger p-1">
                                                    <strong>
                                                        <?php echo e($message); ?>

                                                    </strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </section>

                                        <section class="col-6 col-md-3">
                                            <div class="form-group">
                                                <input type="text" name="meta_value[]"
                                                    class="form-control form-control-sm" value="<?php echo e($meta->meta_value); ?>">
                                            </div>
                                            <?php $__errorArgs = ['meta_value.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="alert_required text-danger p-1">
                                                    <strong>
                                                        <?php echo e($message); ?>

                                                    </strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </section>

                                    </section>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </section>

                            <section class="col-12">
                                <button class="btn btn-primary btn-sm">ثبت</button>
                            </section>
                        </section>
                    </form>
                </section>

            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admin-asset/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-asset/jalalidatepicker/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-asset/jalalidatepicker/persian-datepicker.min.js')); ?>"></script>
    <script>
        CKEDITOR.replace('introduction');
    </script>

    

    <script>
        $(document).ready(function() {
            var tags_input = $('#tags');
            var select_tags = $('#select_tags');
            var default_tags = tags_input.val();
            var default_data = null;

            if (tags_input.val() !== null && tags_input.val().length > 0) {
                default_data = default_tags.split(',');
            }

            select_tags.select2({
                placeholder: 'لطفا تگ های خود را وارد نمایید',
                tags: true,
                data: default_data
            });
            select_tags.children('option').attr('selected', true).trigger('change');


            $('#form').submit(function(event) {
                if (select_tags.val() !== null && select_tags.val().length > 0) {
                    var selectedSource = select_tags.val().join(',');
                    tags_input.val(selectedSource)
                }
            })
        })
    </script>

    <script>
        // تبدیل اعداد فارسی به انگلیسی
        function persianToEnglishNumbers(str) {
            if (!str) return '';
            const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            return str.replace(/[۰-۹]/g, d => persian.indexOf(d));
        }

        // فرمت عدد با سه‌رقمی و اعداد فارسی
        function formatPrice(input) {
            const cursorPos = input.selectionStart;
            const raw = persianToEnglishNumbers(input.value.replace(/[^\d۰-۹]/g, ''));
            input.dataset.rawValue = raw;

            if (raw) {
                const formatted = Number(raw).toLocaleString('fa-IR');
                const diff = formatted.length - input.value.length;
                input.value = formatted;

                // تنظیم مکان‌نما برای جلوگیری از پرش
                const newPos = Math.max(cursorPos + diff, 0);
                input.setSelectionRange(newPos, newPos);
            } else {
                input.value = '';
            }
        }

        // قبل از ارسال فرم، حذف کاماها و تبدیل به عدد انگلیسی
        document.addEventListener('DOMContentLoaded', () => {
            const form = document.querySelector('form');
            const priceInput = document.getElementById('price');

            // لود اولیه: فرمت مقدار موجود در input
            if (priceInput.value) {
                formatPrice(priceInput);
            }

            // قبل از ارسال فرم
            form.addEventListener('submit', () => {
                let value = persianToEnglishNumbers(priceInput.value);
                value = value.replace(/٬|,/g, '');
                priceInput.value = value;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/market/product/edit.blade.php ENDPATH**/ ?>