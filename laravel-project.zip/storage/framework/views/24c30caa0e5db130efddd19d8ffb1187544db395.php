<?php if(session('alert-section-success')): ?>


<div class="alert alert-success" role="alert">
 <?php echo e(session('alert-section-success')); ?>

</div>


<?php endif; ?>
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/alerts/alert-section/success.blade.php ENDPATH**/ ?>