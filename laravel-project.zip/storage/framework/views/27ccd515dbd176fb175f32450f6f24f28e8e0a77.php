
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<span class="sidebar-nav-sub-item-title">
    <a href="<?php echo e(route('customer.products', ['category' => $category->id ,'search' => request()->search, 'sort' =>  request()->sort, 'min_price' => request()->min_price, 'max_price' => request()->max_price, 'brands' => request()->brands])); ?>"  class="d-inline"><?php echo e($category->name); ?></a>
    <?php if($category->children->count() > 0): ?>
    <i class="fa fa-angle-left"></i>
    <?php endif; ?>
</span>
<?php echo $__env->make('customer.layouts.partials.sub-categories', ['subCategories' => $category->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/customer/layouts/partials/categories.blade.php ENDPATH**/ ?>