<script src="<?php echo e(asset('admin-asset/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('admin-asset/js/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-asset/js/grid.js')); ?>"></script>
<script src="<?php echo e(asset('admin-asset\select2\js\select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-asset\sweetalert\sweetalert2.min.js')); ?>"></script>
<script>
        let notificationDropdown = document.getElementById('header-notification-toggle');
        notificationDropdown.addEventListener('click', function(){

            $.ajax({
                type : "POST",
                url : '/admin/notification/read-all',
                data : {_token: "<?php echo e(csrf_token()); ?>" },
                success : function(){

                }
            })
        });
    </script>





<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/layouts/script.blade.php ENDPATH**/ ?>