<?php if(session('swal-success')): ?>
    <script>
        $(document).ready(function (){
            Swal.fire({
                title: 'موفقیت',
                text: '<?php echo e(session('swal-success')); ?>',
                icon: 'success',
                confirmButtonText: 'باشه',
            });
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/alerts/sweetalert/success.blade.php ENDPATH**/ ?>