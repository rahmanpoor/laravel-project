<aside id="sidebar" class="sidebar">
    <section class="sidebar-container">
        <section class="sidebar-wrapper">

            <a href="<?php echo e(route('customer.home')); ?>" class="sidebar-link" target="_blank">
                <i class="fas fa-solid fa-store"></i>
                <span>فروشگاه</span>
            </a>

            <hr>


            <a href="<?php echo e(route('admin.home')); ?>" class="sidebar-link">
                <i class="fas fa-home"></i>
                <span>خانه</span>
            </a>

            <section class="sidebar-part-title">بخش فروش</section>

            <section class="sidebar-group-link">
                <section class="sidebar-dropdown-toggle">
                    <i class="fas fa-store icon"></i>
                    <span>ویترین</span>
                    <i class="fas fa-angle-left angle"></i>
                </section>
                <section class="sidebar-dropdown">
                    <a href="<?php echo e(route('admin.market.category.index')); ?>">دسته بندی</a>
                    <a href="<?php echo e(route('admin.market.property.index')); ?>">فرم کالا</a>
                    <a href="<?php echo e(route('admin.market.brand.index')); ?>">برندها</a>
                    <a href="<?php echo e(route('admin.market.product.index')); ?>">کالاها</a>
                    <a href="<?php echo e(route('admin.market.store.index')); ?>">انبار</a>
                    <a href="<?php echo e(route('admin.market.comment.index')); ?>">نظرات</a>
                </section>
            </section>

            <section class="sidebar-group-link">
                <section class="sidebar-dropdown-toggle">
                    <i class="fas fa-box-open icon"></i>
                    <span>سفارشات</span>
                    <i class="fas fa-angle-left angle"></i>
                </section>
                <section class="sidebar-dropdown">
                    


                    <a href="<?php echo e(route('admin.market.order.sending')); ?>">در حال ارسال </a>

                    <a href="<?php echo e(route('admin.market.order.delivered')); ?>">تحویل شده</a>
                    
                    <a href="<?php echo e(route('admin.market.order.canceled')); ?>">لغو شده</a>
                    
                    <a href="<?php echo e(route('admin.market.order.all')); ?>">تمام سفارشات</a>
                </section>
            </section>

            <section class="sidebar-group-link">
                <section class="sidebar-dropdown-toggle">
                    <i class="fas fa-credit-card  icon"></i>
                    <span>پرداخت ها</span>
                    <i class="fas fa-angle-left angle"></i>
                </section>
                <section class="sidebar-dropdown">
                    <a href="<?php echo e(route('admin.market.payment.index')); ?>">تمام پرداخت ها</a>
                    <a href="<?php echo e(route('admin.market.payment.online')); ?>">پرداخت های آنلاین</a>
                    <a href="<?php echo e(route('admin.market.payment.offline')); ?>">پرداخت های آفلاین</a>
                    <a href="<?php echo e(route('admin.market.payment.cash')); ?>">پرداخت در محل</a>
                </section>
            </section>

            

            <a href="<?php echo e(route('admin.market.delivery.index')); ?>" class="sidebar-link">
                <i class="fas fa-truck"></i>
                <span>روش های ارسال</span>
            </a>



            <section class="sidebar-part-title">بخش محتوی</section>


            <a href="<?php echo e(route('admin.content.category.index')); ?>" class="sidebar-link">
                <i class="fas fa-layer-group"></i>
                <span>دسته بندی</span>
            </a>

            <a href="<?php echo e(route('admin.content.post.index')); ?>" class="sidebar-link">
                <i class="fas fa-file-alt"></i>
                <span>پست ها</span>
            </a>
            <a href="<?php echo e(route('admin.content.comment.index')); ?>" class="sidebar-link">
                <i class="fas fa-comments"></i>
                <span>نظرات</span>
            </a>
            <a href="<?php echo e(route('admin.content.menu.index')); ?>" class="sidebar-link">
                <i class="fas fa-bars"></i>
                <span>منو</span>
            </a>
            <a href="<?php echo e(route('admin.content.faq.index')); ?>" class="sidebar-link">
                <i class="fas fa-question"></i>
                <span>سوالات متداول</span>
            </a>
            <a href="<?php echo e(route('admin.content.page.index')); ?>" class="sidebar-link">
                <i class="fas fa-pager"></i>
                <span>پیج ساز</span>
            </a>
            <a href="<?php echo e(route('admin.content.banner.index')); ?>" class="sidebar-link">
                <i class="fas fa-image"></i>
                <span>بنرها</span>
            </a>



            <section class="sidebar-part-title">بخش کاربران</section>
            <a href="<?php echo e(route('admin.user.admin-user.index')); ?>" class="sidebar-link">
                <i class="fas fa-crown"></i>
                <span>کاربران ادمین</span>
            </a>
            <a href="<?php echo e(route('admin.user.customer.index')); ?>" class="sidebar-link">
                <i class="fas fa-users-cog"></i>
                <span>مشتریان</span>
            </a>

            <section class="sidebar-group-link">
                <section class="sidebar-dropdown-toggle">
                    <i class="fas fa-user-shield icon"></i>
                    <span>سطوح دسترسی</span>
                    <i class="fas fa-angle-left angle"></i>
                </section>
                <section class="sidebar-dropdown">
                    <a href="<?php echo e(route('admin.user.role.index')); ?>">مدیریت نقش ها</a>
                    <a href="<?php echo e(route('admin.user.permission.index')); ?>">مدیریت دسترسی ها</a>

                </section>
            </section>


            



            



            <section class="sidebar-part-title">اطلاع رسانی</section>
            <a href="<?php echo e(route('admin.notify.email.index')); ?>" class="sidebar-link">
                <i class="fas fa-envelope"></i>
                <span>اعلامیه ایمیلی</span>
            </a>
            <a href="<?php echo e(route('admin.notify.sms.index')); ?>" class="sidebar-link">
                <i class="fas fa-sms"></i>
                <span>اعلامیه پیامکی</span>
            </a>







            <section class="sidebar-part-title">تنظیمات</section>
            <section class="sidebar-group-link">
                <section class="sidebar-dropdown-toggle">
                    <i class="fas fa-cog icon"></i>
                    <span>تنظیمات فوتر</span>
                    <i class="fas fa-angle-left angle"></i>
                </section>
                <section class="sidebar-dropdown">
                    <a href="<?php echo e(route('admin.footer.feature.index')); ?>">مزایای فروشگاه</a>
                    <a href="<?php echo e(route('admin.footer.link.index')); ?>">لینک ها</a>
                     <a href="<?php echo e(route('admin.footer.social.index')); ?>">همراه ما باشید</a>
                     <a href="<?php echo e(route('admin.footer.badge.index')); ?>">نماد ها</a>
                     <a href="<?php echo e(route('admin.footer.setting.index')); ?>">تنظیمات</a>

                </section>
            </section>

            
            <a href="<?php echo e(route('admin.setting.index')); ?>" class="sidebar-link">
                <i class="fas fa-cog"></i>
                <span>تنظیمات سایت</span>
            </a>

        </section>
    </section>
</aside>
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>