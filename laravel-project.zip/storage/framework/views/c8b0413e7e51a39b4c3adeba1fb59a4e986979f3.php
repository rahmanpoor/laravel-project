<?php $__env->startSection('head-tag'); ?>
    <title><?php echo e($page->title); ?></title>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <!-- start cart -->
    <section class="mb-4">
        <section class="container-xxl">
            <section class="row">
                <section class="col">
                    <!-- start product info -->
                    <section class="col-md-12">

                        <section class="content-wrapper bg-white p-3 rounded-2 mb-4">

                            <?php echo $page->body; ?>

                        </section>

                    </section>
                    <!-- end product info -->
                </section>
            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.master-two-col', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/customer/page.blade.php ENDPATH**/ ?>