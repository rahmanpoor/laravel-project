<!-- start footer -->
<footer class="footer">
    <section class="container-xxl my-4">
        <section class="row">
            <section class="col">
                <section class="footer-shop-features d-md-flex justify-content-md-around align-items-md-center">

                    <?php $__currentLoopData = $footerFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <section class="footer-shop-features-item">
                            <img src="<?php echo e(asset($footerFeature->image)); ?>" alt="<?php echo e($footerFeature->title); ?>">
                            <section class="text-center"><?php echo e($footerFeature->title); ?></section>
                        </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </section>
            </section>
        </section>
        <section class="row">
            <section class="col-md">
                <?php $__currentLoopData = $firstColumnLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section><a class="text-decoration-none text-muted d-inline-block my-2"
                            href="<?php echo e($link->url); ?>"><?php echo e($link->title); ?></a></section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="col-md">
                <?php $__currentLoopData = $secondColumnLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section><a class="text-decoration-none text-muted d-inline-block my-2"
                            href="<?php echo e($link->url); ?>"><?php echo e($link->title); ?></a></section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="col-md">
                <?php $__currentLoopData = $thirdColumnLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section><a class="text-decoration-none text-muted d-inline-block my-2"
                            href="<?php echo e($link->url); ?>"><?php echo e($link->title); ?></a></section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="col-md-5">
                <section>
                    <section class="text-dark fw-bold">همراه ما باشید!</section>
                    <section class="my-3">
                        <?php $__currentLoopData = $footerSocials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($social->url); ?>" class="text-muted text-decoration-none me-5"><i
                                    class="fab fa-<?php echo e($social->icon); ?>"></i></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </section>
                    
                    <section class="d-flex align-items-center gap-3 flex-wrap">
                        <?php $__currentLoopData = $footerBadges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <section class="badge">
                                <?php echo $badge->script; ?>

                            </section>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </section>
                    
                </section>
            </section>
        </section>

        <section class="row my-5">
            <section class="col">
                <section class="fw-bold"><?php echo e($footerSetting->title); ?></section>
                <section class="text-muted footer-intro"><?php echo e($footerSetting->description); ?></section>
            </section>
        </section>

        <section class="row border-top pt-4">
            <section class="col">
                <section class="text-muted footer-intro text-center">
                    <?php echo e($footerSetting->copyright); ?>

                </section>
            </section>
        </section>
    </section>
</footer>
<!-- end footer -->
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/customer/layouts/footer.blade.php ENDPATH**/ ?>