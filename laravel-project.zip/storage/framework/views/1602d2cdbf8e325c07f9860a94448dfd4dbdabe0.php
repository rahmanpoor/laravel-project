<?php if(session('alert-section-info')): ?>


<div class="alert alert-info" role="alert">
 <?php echo e(session('alert-section-info')); ?>

</div>


<?php endif; ?>

<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/alerts/alert-section/info.blade.php ENDPATH**/ ?>