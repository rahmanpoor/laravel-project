 <section class="sidebar-nav-sub-sub-wrapper py-1 px-1">
     <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <section class="sidebar-nav-sub-sub-item" class="d-inline"><a
                 href="<?php echo e(route('customer.products', $subCategory->id)); ?>"><?php echo e($subCategory->name); ?>

                 <?php if($subCategory->children->count() > 0): ?>
                     <i class="fa fa-angle-left"></i>
                 <?php endif; ?>
             </a>
         </section>
         <?php if($subCategory->children): ?>
             <?php echo $__env->make('customer.layouts.partials.sub-categories', [
                 'subCategories' => $subCategory->children,
             ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </section>
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/customer/layouts/partials/sub-categories.blade.php ENDPATH**/ ?>