<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" type="image/png" href="<?php echo e(asset('admin-asset\images\icon\admin-logo.jpg')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-asset/css/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-asset/fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-asset/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-asset/css/grid.css')); ?>">
    <link href="<?php echo e(asset('admin-asset\select2\css\select2.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin-asset\sweetalert\sweetalert2.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('admin-asset/css/style.css')); ?>">
<?php /**PATH C:\Users\hp-laptop\Desktop\laravel-project\resources\views/admin/layouts/head-tag.blade.php ENDPATH**/ ?>